import './App.css'

function App() {

  return (
    <>
      <h1>React SetUp</h1>
    </>
  )
}

export default App
